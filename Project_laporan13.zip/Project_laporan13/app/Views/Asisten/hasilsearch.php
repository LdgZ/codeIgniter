<!DOCTYPE html>
<html lang="en">
<head>
    <!-- ... -->
</head>
<body>
    <!-- ... -->
    <h2>Hasil Pencarian:</h2>
    <?php if ($asisten): ?>
        <p>NIM yang ditemukan: <?= $asisten ?></p>
    <?php else: ?>
        <p>NIM tidak ditemukan.</p>
    <?php endif; ?>
</body>
</html>
