<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pencarian Asisten</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 20px;
        }
        .bg-success {
            background-color: #28a745;
        }
        .text-white {
            color: #fff;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="bg-warning p-4 mt-4 text-black rounded">
            <h1 class="text-center">Pencarian Asisten</h1>
        </div>
        <form action="/asisten/search" method="post" class="mt-4">
            <?= csrf_field() ?>
            <div class="form-group">
                <label for="key">Pencarian:</label>
                <input type="text" class="form-control" name="key" id="key" placeholder="Masukkan NIM" required>
            </div>
            <center>
            <button type="submit" class="btn btn-success">Cari</button>
            </center>
        </form>

        <?php if (!empty($hasil)) : ?>
            <div class="bg-warning p-4 mt-4 text-black rounded">
                <h1 class="text-center">Hasil Pencarian</h1>
                <p>Nama: <?= $hasil['nama'] ?></p>
                <p>Praktikum: <?= $hasil['praktikum'] ?></p>
                <p>IPK: <?= $hasil['ipk'] ?></p>
            </div>
        <?php endif; ?>
    </div>

    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
</body>
</html>
