<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Form Update Data</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 20px;
        }

    h1 {
        text-align: center;
    }

    form {
        max-width: 400px;
        margin: 0 auto;
    }

    label {
        display: block;
        margin-bottom: 5px;
    }

    input[type="text"] {
        width: 100%;
        padding: 8px;
        margin-bottom: 10px;
    }

    input[type="submit"] {
        width: 100%;
        padding: 10px;
        background-color: #4CAF50;
        color: white;
        border: none;
        cursor: pointer;
    }

    input[type="submit"]:hover {
        background-color: #45a049;
    }
</style>
</head>
<body>
    <h1>UPDATE DATA ASISTEN PRAKTIKUM</h1>
    <form action="/asisten/update" method="post">
        <?= csrf_field() ?>
        <label for="nim">NIM:</label>
        <input type="text" name="nim" id="nim" required><br>

    <label for="nama">NAMA:</label>
    <input type="text" name="nama" id="nama" required><br>

    <label for="praktikum">PRAKTIKUM:</label>
    <input type="text" name="praktikum" id="praktikum" required><br>

    <input type="submit" value="Update">
</form>
</body>
</html>