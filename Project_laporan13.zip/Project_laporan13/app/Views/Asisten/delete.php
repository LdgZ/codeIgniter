<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Form Delete Data</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 20px;
        }
    h1 {
        text-align: center;
    }

    form {
        max-width: 400px;
        margin: 0 auto;
    }

    label {
        display: block;
        margin-bottom: 5px;
    }

    input[type="text"] {
        width: 100%;
        padding: 8px;
        margin-bottom: 10px;
    }

    input[type="submit"] {
        width: 100%;
        padding: 10px;
        background-color: #B31312;
        color: white;
        border: none;
        cursor: pointer;
    }

    input[type="submit"]:hover {
        background-color: #B31312;
    }
</style>
</head>
<body>
    <h1>DELETE DATA ASISTEN PRAKTIKUM</h1>
    <form action="/asisten/delete" method="post">
        <?= csrf_field() ?>
        <label for="nim">NIM:</label>
        <input type="text" name="nim" id="nim" required><br>

    <input type="submit" value="Delete">
</form>
</body>
</html>